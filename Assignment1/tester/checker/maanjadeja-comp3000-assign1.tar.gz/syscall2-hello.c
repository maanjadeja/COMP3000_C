#include <asm/unistd.h>
#include <sys/types.h>

char *buf = "Hello world!\n";

// #define __NR_write 1
int main(int argc, char *argv)
{
        ssize_t result;
        int fd = 1;
        ssize_t size = 13;
    asm volatile
    (
        "syscall"
        : "=a" (result)
        //                 EDI      RSI       RDX
        : "0"(__NR_write), "D"(fd), "S"(buf), "d"(size)
        : "rcx", "r11", "memory"
    );
        return (int) result;
}